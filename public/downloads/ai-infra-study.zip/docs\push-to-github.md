# 把本仓库推到 GitHub 的三种方法

> 现状说明（重要）：本仓库已经初始化好 git 并完成首次提交，但**没有配置任何远程仓库和凭据**。
> 推送前你需要先创建一个 GitHub 仓库并把地址填进来。

---

## 第 0 步：在 GitHub 上创建空仓库

1. 打开 https://github.com/new
2. 仓库名建议：`ai-infra-study`
3. 选择 **Public**（私有也行，但公开更利于你以后展示项目）
4. **不要勾选** "Add a README / .gitignore / license"（避免与本地首次提交冲突）
5. 点 Create repository，复制地址，形如：
   - HTTPS：`https://github.com/<你的用户名>/ai-infra-study.git`
   - SSH：`git@github.com:<你的用户名>/ai-infra-study.git`

---

## 第 1 步：配置身份（本机目前是空的，必须做）

```powershell
git config --global user.name  "你的名字"
git config --global user.email "你的邮箱"
```

> 本机检测结果：
> - `git` 已安装：`C:\Program Files\Git\cmd\git.exe`，版本 2.55.0
> - `user.name` / `user.email`：**未配置**
> - `gh` CLI：**未安装**
> - SSH 密钥：**不存在**（`~/.ssh` 无）
> - 直连 GitHub：**不通**；系统 git 全局设了代理 `http://127.0.0.1:7897`，
>   但 Windows 的 schannel 后端报 `SEC_E_NO_CREDENTIALS`；
>   改用 **openssl 后端 + 该代理** 后可正常访问 GitHub（已实测 `git ls-remote` 成功）。

---

## 方法 A：HTTPS + Personal Access Token（最省事，推荐）

```powershell
# 1. 用 openssl 后端绕过 schannel 的凭据报错
git config --global http.sslBackend openssl
# （如已存在 http.proxy / https.proxy 配置，确认端口是本机代理 7897）

# 2. 关联远程仓库
git remote add origin https://github.com/<你的用户名>/ai-infra-study.git
git branch -M main
git push -u origin main
```

首次 push 会弹出浏览器登录（Git Credential Manager）或要求输入用户名+密码。
**GitHub 已不接受密码**，需要使用 **Personal Access Token（PAT）**：
- 生成：https://github.com/settings/tokens （选 `repo` 权限，有效期建议 90 天）
- 登录时：用户名填 GitHub 用户名，密码处粘贴 token

> 若 `git push` 卡住或超时，检查代理：
> ```powershell
> git config --global http.proxy  http://127.0.0.1:7897
> git config --global https.proxy http://127.0.0.1:7897
> ```

---

## 方法 B：SSH 密钥（长期更顺手）

```powershell
# 1. 生成密钥（一路回车即可）
ssh-keygen -t ed25519 -C "你的邮箱"

# 2. 复制公钥内容，粘贴到 https://github.com/settings/keys
Get-Content "$env:USERPROFILE\.ssh\id_ed25519.pub" | Set-Clipboard

# 3. 验证
ssh -T git@github.com    # 看到 "Hi <用户名>!" 即成功

# 4. 关联并推送
git remote add origin git@github.com:<你的用户名>/ai-infra-study.git
git branch -M main
git push -u origin main
```

> 注意：本机 ssh 走 22 端口可能被墙，可改用 443 端口：
> 在 `~/.ssh/config` 中加：
> ```
> Host github.com
>   HostName ssh.github.com
>   Port 443
>   User git
>   ProxyCommand connect -H 127.0.0.1:7897 %h %p
> ```
> （`connect` 命令随 Git for Windows 提供）

---

## 方法 C：安装 `gh` CLI 一键创建并推送

```powershell
winget install --id GitHub.cli -e
gh auth login          # 选 GitHub.com → HTTPS → 浏览器登录
gh repo create ai-infra-study --public --source . --remote origin --push
```

一条命令完成"建仓库 + 关联 + 推送"。

---

## 推送后的日常同步

```powershell
git add -A
git commit -m "week2: 完成 micrograd 手推梯度"
git push
```

**建议的打卡习惯**：每周学习结束提交一次，commit message 写清"做了什么 + 测到什么数字"。
几个月后，你的提交历史本身就是一份学习履历。

---

## 常见报错速查

| 报错 | 原因 | 解决 |
|---|---|---|
| `SEC_E_NO_CREDENTIALS` / `schannel: AcquireCredentialsHandle failed` | Windows schannel 后端问题 | `git config --global http.sslBackend openssl` |
| `Failed to connect ... 7897` | 代理软件没开 | 启动代理，或去掉 proxy 配置直连 |
| `remote origin already exists` | 重复添加 | `git remote set-url origin <新地址>` |
| `Support for password authentication was removed` | 用了账号密码 | 改用 PAT |
| `fatal: refusing to merge unrelated histories` | 远程已初始化过 content | `git pull origin main --allow-unrelated-histories` |

---

## 需要我帮你做的部分

网络和账号凭据在我这边无法访问，但以下我可以代劳：
1. 帮你**改写 `.git/config` 里的 remote 地址**（你把仓库地址给我即可）
2. 帮你**生成并配置 `.gitignore` / PR 模板 / CI** 等仓库配套文件
3. 把学习打卡做成 **GitHub Actions 自动检查**（例如每周该完成什么）
