# AI Infra 与人工智能入门路线

> 给「会 Python、数学生疏、有本地 Nvidia GPU」的同学，一份**可执行、有勾选框、带可运行计算工具**的 17 周学习计划。
> 覆盖方向：**训练/推理系统** + **平台工程（MLOps）**。

这份仓库不是又一份"资源合集"，而是一个**学习工作区**：
- `roadmap/` 里有带勾选框的逐周任务，你可以直接在这个仓库里打卡；
- `notes/` 给你论文的精读清单和"读前先想的问题"；
- `code/` 里每个脚本都能直接跑，用来建立 AI Infra 最核心的成本直觉；
- `projects/` 是三个可写进简历的项目的脚手架与验收标准。

---

## 目录结构

```
ai-infra-study/
├── README.md                  ← 你在这里
├── roadmap/
│   ├── 00-roadmap.md          ← 总路线图（11 周主线 + 6 周平台）
│   ├── 01-week-by-week.md     ← 逐周任务清单，直接勾选打卡
│   └── 02-math-minimum.md     ← AI Infra 需要的"最小数学集合"
├── notes/
│   ├── 01-reading-list.md     ← 精选 8 篇论文 + 每篇要回答的问题
│   └── 02-reading-template.md ← 每篇论文的笔记模板
├── code/
│   ├── week1_roofline.py      ← 算力/带宽瓶颈计算器
│   ├── week1_memory_budget.py ← 显存账本估算器
│   ├── week2_kv_cache.py      ← KV cache 与上下文长度、并发的关系
│   └── week3_batching.py      ← continuous batching 的吞吐直觉
├── projects/
│   ├── README.md              ← 三个项目的要求与验收标准
│   ├── 01-serving-benchmark/  ← 推理性能剖析
│   ├── 02-mini-serving-static/← mini serving 引擎
│   └── 03-train-parallel/     ← 训练加速对比
└── docs/
    ├── push-to-github.md      ← 把本仓库推到 GitHub 的三种方法
    └── local-environment.md   ← 本地 GPU 环境自检清单
```

---

## 快速开始

```powershell
# 1. 运行第一个工具（Windows 上 git-bash 或直接用绝对路径的 python）
python code/week1_roofline.py
python code/week1_memory_budget.py

# 2. 打开本周任务
#    roadmap/01-week-by-week.md
```

> 脚本只依赖 Python 标准库（`week2_kv_cache.py` / `week3_batching.py` 可选依赖 numpy），
> 目的是让你在**还没配好 CUDA 环境时就能先建立成本直觉**。

---

## 核心结论速查（先记住这 5 条）

1. **解码阶段是带宽受限的**。M=1 的矩阵-向量乘，4090 的算力利用率只有约 0.6%。所以单卡推理靠 **batching** 加速，而不是换卡。
2. **训练显存 ≈ 16 字节/参数**（fp16 权重 + 梯度 + fp32 master + Adam 两状态）。8B 模型 ≈ 123GB，**单卡跑不动是对的**，这就是 FSDP/ZeRO 存在的数学原因。
3. **长上下文时 KV cache 会反超权重**。这是 PagedAttention / vLLM 和 GQA 被广泛采用的直接工程动因。
4. **Prefill 是算力受限、Decode 是带宽受限**。所谓 "prefill/decode 分离"（如 Mooncake）就是把两种不同瓶颈的负载放到不同资源上。
5. **AI Infra 的核心能力是测量，不是背诵**。每个"理论加速 X 倍"都要立刻在卡上验证。

---

## 里程碑

| 阶段 | 周数 | 交付物 | 完成标志 |
|---|---|---|---|
| 成本直觉 | 第 1 周 | 能算出模型推理延迟与显存需求 | 手算结果与脚本误差 < 20% |
| AI 基本功 | 第 2–5 周 | 在 GPU 上从零训练字符级 GPT | 能解释训练显存被谁占用 |
| 训练系统 | 第 6–9 周 | DDP / FSDP / TP 最小例子跑通 | 能画出并行策略的通信量对比 |
| 推理系统 | 第 10–13 周 | vLLM 压测曲线 + mini server | 吞吐/延迟曲线形状能被 Roofline 解释 |
| 平台工程 | 第 14–17 周 | K8s 上跑一次 GPU 推理服务 | 能用 profile 定位一次瓶颈 |
| 项目 | 第 19 周+ | 三选一做出量化结果 | 写出"我让 X 提升 Y%" |

---

## 许可

内容采用 [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)，代码采用 MIT。随意 fork、改写、提交 PR。
